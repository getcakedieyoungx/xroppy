
export enum RowType {
    Header = <any> 'Header',
    Section = <any> 'Section',
    Row = <any> 'Row',
    SummaryRow = <any> 'SummaryRow'
}
