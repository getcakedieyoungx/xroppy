
/**
* See Asset Status Codes.
*/
export enum AssetStatusQueryParam {
    DRAFT = <any> 'DRAFT',
    REGISTERED = <any> 'REGISTERED',
    DISPOSED = <any> 'DISPOSED'
}
