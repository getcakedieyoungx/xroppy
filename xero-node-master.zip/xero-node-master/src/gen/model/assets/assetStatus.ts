
/**
* See Asset Status Codes.
*/
export enum AssetStatus {
    Draft = <any> 'Draft',
    Registered = <any> 'Registered',
    Disposed = <any> 'Disposed'
}
