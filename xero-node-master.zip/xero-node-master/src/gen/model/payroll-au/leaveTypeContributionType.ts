
export enum LeaveTypeContributionType {
    SGC = <any> 'SGC',
    SALARYSACRIFICE = <any> 'SALARYSACRIFICE',
    EMPLOYERADDITIONAL = <any> 'EMPLOYERADDITIONAL',
    EMPLOYEE = <any> 'EMPLOYEE'
}
