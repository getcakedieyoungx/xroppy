
export enum EmploymentType {
    EMPLOYEE = <any> 'EMPLOYEE',
    CONTRACTOR = <any> 'CONTRACTOR'
}
