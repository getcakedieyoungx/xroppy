
export enum LeavePeriodStatus {
    SCHEDULED = <any> 'SCHEDULED',
    PROCESSED = <any> 'PROCESSED',
    REQUESTED = <any> 'REQUESTED',
    REJECTED = <any> 'REJECTED'
}
