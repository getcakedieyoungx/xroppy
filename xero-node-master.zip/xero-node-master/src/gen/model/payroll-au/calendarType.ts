
export enum CalendarType {
    WEEKLY = <any> 'WEEKLY',
    FORTNIGHTLY = <any> 'FORTNIGHTLY',
    FOURWEEKLY = <any> 'FOURWEEKLY',
    MONTHLY = <any> 'MONTHLY',
    TWICEMONTHLY = <any> 'TWICEMONTHLY',
    QUARTERLY = <any> 'QUARTERLY'
}
