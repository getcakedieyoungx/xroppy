
/**
* How the requested leave will be paid out, e.g. cashed out.
*/
export enum PayOutType {
    DEFAULT = <any> 'DEFAULT',
    CASHEDOUT = <any> 'CASHED_OUT'
}
