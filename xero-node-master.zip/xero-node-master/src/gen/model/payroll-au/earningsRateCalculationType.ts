
export enum EarningsRateCalculationType {
    USEEARNINGSRATE = <any> 'USEEARNINGSRATE',
    ENTEREARNINGSRATE = <any> 'ENTEREARNINGSRATE',
    ANNUALSALARY = <any> 'ANNUALSALARY'
}
