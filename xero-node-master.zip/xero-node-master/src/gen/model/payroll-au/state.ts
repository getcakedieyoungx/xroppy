
/**
* State abbreviation for employee home address
*/
export enum State {
    ACT = <any> 'ACT',
    NSW = <any> 'NSW',
    NT = <any> 'NT',
    QLD = <any> 'QLD',
    SA = <any> 'SA',
    TAS = <any> 'TAS',
    VIC = <any> 'VIC',
    WA = <any> 'WA'
}
