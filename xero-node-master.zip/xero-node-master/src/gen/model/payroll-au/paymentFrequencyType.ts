
export enum PaymentFrequencyType {
    WEEKLY = <any> 'WEEKLY',
    MONTHLY = <any> 'MONTHLY',
    FORTNIGHTLY = <any> 'FORTNIGHTLY',
    QUARTERLY = <any> 'QUARTERLY',
    TWICEMONTHLY = <any> 'TWICEMONTHLY',
    FOURWEEKLY = <any> 'FOURWEEKLY',
    YEARLY = <any> 'YEARLY'
}
