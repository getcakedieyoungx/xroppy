
export enum SuperannuationCalculationType {
    FIXEDAMOUNT = <any> 'FIXEDAMOUNT',
    PERCENTAGEOFEARNINGS = <any> 'PERCENTAGEOFEARNINGS',
    STATUTORY = <any> 'STATUTORY'
}
