
export enum AllowanceCategory {
    NONDEDUCTIBLE = <any> 'NONDEDUCTIBLE',
    UNIFORM = <any> 'UNIFORM',
    PRIVATEVEHICLE = <any> 'PRIVATEVEHICLE',
    HOMEOFFICE = <any> 'HOMEOFFICE',
    TRANSPORT = <any> 'TRANSPORT',
    GENERAL = <any> 'GENERAL',
    OTHER = <any> 'OTHER'
}
