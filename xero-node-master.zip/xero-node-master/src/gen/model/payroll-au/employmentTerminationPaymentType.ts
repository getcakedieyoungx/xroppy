
export enum EmploymentTerminationPaymentType {
    O = <any> 'O',
    R = <any> 'R'
}
