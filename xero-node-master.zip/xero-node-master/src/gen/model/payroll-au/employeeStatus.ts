
/**
* Employee Status Types
*/
export enum EmployeeStatus {
    ACTIVE = <any> 'ACTIVE',
    TERMINATED = <any> 'TERMINATED'
}
