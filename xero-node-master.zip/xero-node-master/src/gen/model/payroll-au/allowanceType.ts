
export enum AllowanceType {
    CAR = <any> 'CAR',
    TRANSPORT = <any> 'TRANSPORT',
    LAUNDRY = <any> 'LAUNDRY',
    MEALS = <any> 'MEALS',
    TRAVEL = <any> 'TRAVEL',
    OTHER = <any> 'OTHER',
    JOBKEEPER = <any> 'JOBKEEPER',
    TOOLS = <any> 'TOOLS',
    TASKS = <any> 'TASKS',
    QUALIFICATIONS = <any> 'QUALIFICATIONS'
}
