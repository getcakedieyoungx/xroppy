
export enum TimesheetStatus {
    DRAFT = <any> 'DRAFT',
    PROCESSED = <any> 'PROCESSED',
    APPROVED = <any> 'APPROVED',
    REJECTED = <any> 'REJECTED',
    REQUESTED = <any> 'REQUESTED'
}
