
export enum RateType {
    FIXEDAMOUNT = <any> 'FIXEDAMOUNT',
    MULTIPLE = <any> 'MULTIPLE',
    RATEPERUNIT = <any> 'RATEPERUNIT'
}
