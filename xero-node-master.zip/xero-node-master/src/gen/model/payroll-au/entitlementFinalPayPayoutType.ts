
export enum EntitlementFinalPayPayoutType {
    NOTPAIDOUT = <any> 'NOTPAIDOUT',
    PAIDOUT = <any> 'PAIDOUT'
}
