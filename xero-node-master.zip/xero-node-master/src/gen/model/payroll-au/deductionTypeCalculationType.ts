
export enum DeductionTypeCalculationType {
    FIXEDAMOUNT = <any> 'FIXEDAMOUNT',
    PRETAX = <any> 'PRETAX',
    POSTTAX = <any> 'POSTTAX'
}
