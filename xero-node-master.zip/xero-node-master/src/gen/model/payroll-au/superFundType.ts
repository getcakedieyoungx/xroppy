
export enum SuperFundType {
    REGULATED = <any> 'REGULATED',
    SMSF = <any> 'SMSF'
}
