
export enum TFNExemptionType {
    NOTQUOTED = <any> 'NOTQUOTED',
    PENDING = <any> 'PENDING',
    PENSIONER = <any> 'PENSIONER',
    UNDER18 = <any> 'UNDER18'
}
