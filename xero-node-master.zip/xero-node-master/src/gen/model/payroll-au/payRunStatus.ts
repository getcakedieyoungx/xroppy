
export enum PayRunStatus {
    DRAFT = <any> 'DRAFT',
    POSTED = <any> 'POSTED'
}
