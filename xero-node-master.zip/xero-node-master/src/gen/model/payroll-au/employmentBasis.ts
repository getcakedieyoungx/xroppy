
export enum EmploymentBasis {
    FULLTIME = <any> 'FULLTIME',
    PARTTIME = <any> 'PARTTIME',
    CASUAL = <any> 'CASUAL',
    LABOURHIRE = <any> 'LABOURHIRE',
    SUPERINCOMESTREAM = <any> 'SUPERINCOMESTREAM',
    NONEMPLOYEE = <any> 'NONEMPLOYEE'
}
