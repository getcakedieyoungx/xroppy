
/**
* If the statement balances are credit or debit, the CreditDebitIndicator should be specified from the perspective of the Customer.
*/
export enum CreditDebitIndicator {
    CREDIT = <any> 'CREDIT',
    DEBIT = <any> 'DEBIT'
}
